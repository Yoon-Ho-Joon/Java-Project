package game;

import java.util.Random;

import javax.swing.JOptionPane;

public class ThreadSpread implements Runnable {

	private Thread myThread;
	private PlayScreen playScreenView;
	private PlayPanel playPanel;
	private int random;
	private int sleep;
	private int sleepTime;
	private int max = 800;
	public int flag1 = 0;
	public int flag2 = 0;
	private Random obj = new Random();
	private int speed;

	public ThreadSpread(PlayScreen playScreen) {
		myThread = null;
		playScreenView = playScreen;
		sleep = 0;
	}

	public void sleep(int time) {
		sleep = 1;
		sleepTime = time;
	}// sleep() sleep,sleepTime ����

	public void start() {

		if (myThread == null) {
			myThread = new Thread(this);
		}

		myThread.start();

	}

	public void stop() {
		if (myThread != null) {
			myThread.stop();
		}
	}

	public void run() {
		try {

			for (int i = 0; i < 100; i++) {
				speed = obj.nextInt(3) + 3;
				while (playScreenView.list[i].getX() < max) {
					playScreenView.list[i].setVisible(true);
					playScreenView.list[i].setLocation(playScreenView.list[i].getX() + speed,
							playScreenView.list[i].getY());

					if ((playScreenView.lbl.getX() < playScreenView.list[i].getX() + 150
							&& playScreenView.lbl.getX() > playScreenView.list[i].getX())
							|| (playScreenView.lbl.getX() + 100 > playScreenView.list[i].getX()
									&& playScreenView.lbl.getX() + 100 < playScreenView.list[i].getX() + 150)) {

						if ((playScreenView.lbl.getY() + 100) > playScreenView.list[i].getY()) {
							flag1 = 1;

						} else
							flag2 = 1;

					}

					myThread.sleep(10);

				}

				if (flag1 == 1) {

					playScreenView.lbl.setLocation(600, 450);
					playScreenView.life--;
					playScreenView.lifeL.setText("LIFE : " + playScreenView.life);

					if (playScreenView.life <= 0) {
						JOptionPane.showMessageDialog(playScreenView, "You got " + playScreenView.score + "points!", "",
								JOptionPane.PLAIN_MESSAGE);
						playScreenView.score = 0;
						playScreenView.btnS.setEnabled(true);
						playScreenView.view.btnB.setEnabled(true);
						stop();

					}
					flag1 = 0;
					flag2 = 0;

				} else if (flag1 == 0 && flag2 == 1) {
					playScreenView.score += 50;
					playScreenView.scoreL.setText("SCORE : " + playScreenView.score);
					flag1 = 0;
					flag2 = 0;
				}
			}
		} catch (Exception e) {

		}

	}

}
